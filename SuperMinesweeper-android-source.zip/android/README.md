# Super Minesweeper Android wrapper

- Local WebView shell; game HTML/CSS/JS bundled under `app/src/main/assets/game`.
- No network permission; Google Fonts stylesheet removed so gameplay assets load offline.
- WebView DOM storage enabled for the original localStorage saves.
- Unspecified orientation and resize handling allow fold/unfold and rotation to relayout.

Build prerequisites: Android SDK Platform 35, Build Tools 35.x, Gradle 8.11+ and JDK 17+.
Build: `gradle assembleDebug` from this directory.
