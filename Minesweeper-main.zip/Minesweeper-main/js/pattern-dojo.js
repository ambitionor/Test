/**
 * 模式训练道馆 (Pattern Dojo)
 * 交互式扫雷推理模式训练模块
 * 帮助玩家掌握从基础到高级的经典扫雷推理模式
 */

const PatternDojo = (function() {
    const STORAGE_KEY = 'pattern_dojo';

    // ==================== 模式数据 ====================
    // 布局编码：# = 未揭示，. = 已揭示；数字由真实雷位自动计算。

    function parseCells(encoded) {
        if (!encoded) return [];
        return encoded.split(' ').map(function(cell) {
            var pair = cell.split(',');
            return { x: parseInt(pair[0], 10), y: parseInt(pair[1], 10) };
        });
    }

    function createGrid(layout, mines) {
        var mineSet = {};
        mines.forEach(function(mine) { mineSet[mine.x + ',' + mine.y] = true; });

        return layout.map(function(row, y) {
            return row.split('').map(function(cell, x) {
                if (cell === '#') return -1;
                var count = 0;
                for (var dy = -1; dy <= 1; dy++) {
                    for (var dx = -1; dx <= 1; dx++) {
                        if ((dx || dy) && mineSet[(x + dx) + ',' + (y + dy)]) count++;
                    }
                }
                return count;
            });
        });
    }

    function createBoard(layout, mineCells, answerType, targetCells, explanation, flagCells) {
        var mines = parseCells(mineCells);
        return {
            grid: createGrid(layout, mines),
            mines: mines,
            flags: parseCells(flagCells),
            answerType: answerType,
            targets: parseCells(targetCells),
            explanation: explanation
        };
    }

    function createPattern(config) {
        var mines = parseCells(config.example.mines);
        config.exampleBoard = createGrid(config.example.layout, mines);
        config.exampleMines = mines;
        delete config.example;
        return config;
    }

    var PATTERNS = [
        createPattern({
            id: 'corner-1',
            name: '角落数字1',
            level: 1,
            description: '角落的数字是1且只剩一个未揭邻居时，那个格子一定是雷。',
            explanation: '数字1表示周围恰好有1颗雷。角落只有3个邻居；若其中2格已揭示，唯一的未揭格必定是雷。',
            example: { layout: ['.#', '..'], mines: '1,0' },
            trainingBoards: [
                createBoard(['.#', '..'], '1,0', 'mine', '1,0', '左上角的1只剩右侧一个未揭邻居，所以它一定是雷。'),
                createBoard(['#.', '..'], '0,0', 'mine', '0,0', '右上角的1只剩左侧一个未揭邻居，所以它一定是雷。'),
                createBoard(['..', '.#'], '1,1', 'mine', '1,1', '左下角的1只剩右侧一个未揭邻居，所以它一定是雷。'),
                createBoard(['..', '#.'], '0,1', 'mine', '0,1', '右下角的1只剩左侧一个未揭邻居，所以它一定是雷。'),
                createBoard(['#..', '...', '...'], '0,0', 'mine', '0,0', '中心的1只有左上角尚未揭示，因此该格一定是雷。')
            ]
        }),
        createPattern({
            id: 'edge-equals',
            name: '数字等于未揭数',
            level: 1,
            description: '当数字等于周围未揭格数量时，这些未揭格全部是雷。',
            explanation: '数字表示相邻雷数。如果数字与未揭邻居数相等，每个未揭邻居都必须贡献一颗雷。',
            example: { layout: ['###', '...'], mines: '0,0 1,0 2,0' },
            trainingBoards: [
                createBoard(['###', '...'], '0,0 1,0 2,0', 'mine', '0,0 1,0 2,0', '数字3周围恰好有3个未揭格，因此三格全是雷。'),
                createBoard(['#..', '#..', '#..'], '0,0 0,1 0,2', 'mine', '0,0 0,1 0,2', '数字3左侧恰好有3个未揭格，因此三格全是雷。'),
                createBoard(['##', '..'], '0,0 1,0', 'mine', '0,0 1,0', '数字2周围只有上方2个未揭格，因此两格都是雷。'),
                createBoard(['###', '#..', '...'], '0,0 1,0 2,0 0,1', 'mine', '0,0 1,0 2,0 0,1', '中心的数字4周围恰好有4个未揭格，因此全部是雷。'),
                createBoard(['.#', '##'], '1,0 0,1 1,1', 'mine', '1,0 0,1 1,1', '角落的数字3只有3个邻居，三格都必须是雷。')
            ]
        }),
        createPattern({
            id: 'zero-safe',
            name: '0 的全安全',
            level: 1,
            description: '数字0周围没有雷，所有相邻未揭格都可以安全揭开。',
            explanation: '0精确表示周围8格没有雷，因此与0相邻的任何未揭格都一定安全。',
            example: { layout: ['###', '#.#', '###'], mines: '' },
            trainingBoards: [
                createBoard(['###', '#.#', '###'], '', 'safe', '0,0 1,0 2,0 0,1 2,1 0,2 1,2 2,2', '中心是0，周围8个未揭格全部安全。'),
                createBoard(['.#', '##'], '', 'safe', '1,0 0,1 1,1', '角落的0证明其余3格全部安全。'),
                createBoard(['###', '...'], '', 'safe', '0,0 1,0 2,0', '连续的0证明上方3格全部安全。'),
                createBoard(['#...', '....', '...#'], '3,2', 'safe', '0,0', '左上区域的0证明(0,0)安全；远处的雷不影响这个结论。'),
                createBoard(['#####', '.....', '#####'], '', 'safe', '0,0 1,0 2,0 3,0 4,0 0,2 1,2 2,2 3,2 4,2', '中间一排连续的0证明上下两排全部安全。')
            ]
        }),
        createPattern({
            id: 'subtract-safe',
            name: '减法安全',
            level: 2,
            description: '数字所需的雷已全部标出时，其余相邻未揭格全部安全。',
            explanation: '用数字减去相邻的已标记雷数；结果为0时，其余未揭邻居都不可能是雷。',
            example: { layout: ['##', '..'], mines: '0,0' },
            trainingBoards: [
                createBoard(['##', '..'], '0,0', 'safe', '1,0', '数字1已有一颗相邻旗帜，因此另一格安全。', '0,0'),
                createBoard(['###', '...'], '0,0 2,0', 'safe', '1,0', '数字2已有两颗相邻旗帜，因此中间格安全。', '0,0 2,0'),
                createBoard(['#.', '#.', '#.'], '0,0 0,2', 'safe', '0,1', '数字2已有上下两颗相邻旗帜，因此中间格安全。', '0,0 0,2'),
                createBoard(['###', '#.#', '...'], '0,0', 'safe', '1,0 2,0 0,1 2,1', '中心数字1所需的雷已经标出，其余4个未揭邻居全部安全。', '0,0'),
                createBoard(['###', '#.#', '...'], '0,0 1,0 0,1', 'safe', '2,0 2,1', '中心数字3所需的雷已经全部标出，右侧两格安全。', '0,0 1,0 0,1')
            ]
        }),
        createPattern({
            id: 'pattern-121',
            name: '1-2-1 模式',
            level: 2,
            description: '直线边沿出现1-2-1时，两个1对应的外侧格是雷，中间格安全。',
            explanation: '设三格为A、B、C：A+B=1、A+B+C=2、B+C=1，所以A和C是雷，B安全。',
            example: { layout: ['###', '...'], mines: '0,0 2,0' },
            trainingBoards: [
                createBoard(['###', '...'], '0,0 2,0', 'mine', '0,0 2,0', '上沿1-2-1：两个1正上方是雷，中间2正上方安全。'),
                createBoard(['...', '###'], '0,1 2,1', 'mine', '0,1 2,1', '下沿1-2-1：两个1正下方是雷，中间格安全。'),
                createBoard(['#..', '#..', '#..'], '0,0 0,2', 'mine', '0,0 0,2', '左沿1-2-1：两端是雷，中间格安全。'),
                createBoard(['..#', '..#', '..#'], '2,0 2,2', 'mine', '2,0 2,2', '右沿1-2-1：两端是雷，中间格安全。'),
                createBoard(['#####', '.....'], '0,0 2,0 4,0', 'mine', '0,0 2,0 4,0', '连续的1-2-1约束交替推出第1、3、5格是雷。')
            ]
        }),
        createPattern({
            id: 'pattern-1221',
            name: '1-2-2-1 模式',
            level: 2,
            description: '直线边沿出现1-2-2-1时，中间两个2对应的格是雷，两端安全。',
            explanation: '四个约束联立后，外侧两格只能安全，中间两格只能是雷。',
            example: { layout: ['####', '....'], mines: '1,0 2,0' },
            trainingBoards: [
                createBoard(['####', '....'], '1,0 2,0', 'mine', '1,0 2,0', '上沿1-2-2-1：中间两格是雷，两端安全。'),
                createBoard(['....', '####'], '1,1 2,1', 'mine', '1,1 2,1', '下沿1-2-2-1：中间两格是雷，两端安全。'),
                createBoard(['#..', '#..', '#..', '#..'], '0,1 0,2', 'mine', '0,1 0,2', '左沿1-2-2-1：中间两格是雷，两端安全。'),
                createBoard(['..#', '..#', '..#', '..#'], '2,1 2,2', 'mine', '2,1 2,2', '右沿1-2-2-1：中间两格是雷，两端安全。'),
                createBoard(['#####', '.....'], '1,0 2,0', 'mine', '1,0 2,0', '前四个数字形成1-2-2-1，因此第2、3格是雷。')
            ]
        }),
        createPattern({
            id: 'corner-2',
            name: '角落数字2',
            level: 2,
            description: '角落数字2只剩两个未揭邻居时，这两个格子都是雷。',
            explanation: '角落只有3个邻居；其中1格已揭示后，数字2要求剩余两格各有一颗雷。',
            example: { layout: ['.#', '#.'], mines: '1,0 0,1' },
            trainingBoards: [
                createBoard(['.#', '#.'], '1,0 0,1', 'mine', '1,0 0,1', '左上角的2只剩两个未揭邻居，两格都是雷。'),
                createBoard(['#.', '.#'], '0,0 1,1', 'mine', '0,0 1,1', '右上角的2只剩两个未揭邻居，两格都是雷。'),
                createBoard(['.#.', '#..', '...'], '1,0 0,1', 'mine', '1,0 0,1', '左上角的2证明右侧和下方两格都是雷。'),
                createBoard(['.#.', '..#', '...'], '1,0 2,1', 'mine', '1,0 2,1', '右上角的2证明左侧和下方两格都是雷。'),
                createBoard(['...', '..#', '.#.'], '2,1 1,2', 'mine', '2,1 1,2', '右下角的2证明上方和左侧两格都是雷。')
            ]
        }),
        createPattern({
            id: 'overlap',
            name: '重叠约束',
            level: 3,
            description: '比较两个数字共享的未揭格，用约束相减推出独有区域。',
            explanation: '若一个数字的未知邻域包含另一个数字的未知邻域，两者相减就能确定多出来的格子。',
            example: { layout: ['###', '...'], mines: '0,0 2,0' },
            trainingBoards: [
                createBoard(['####', '....'], '0,0 2,0', 'mine', '0,0 2,0', '相邻约束逐项相减，可确定第1、3格是雷。'),
                createBoard(['####', '....'], '1,0 3,0', 'mine', '1,0 3,0', '从左向右比较重叠邻域，可确定第2、4格是雷。'),
                createBoard(['####', '....'], '0,0 3,0', 'mine', '0,0 3,0', '连续比较四个数字的重叠邻域，可确定两端是雷。'),
                createBoard(['###', '..#'], '0,0', 'safe', '2,0 2,1', '两个数字都是1，较大邻域多出的右侧两格都安全。'),
                createBoard(['###', '#..'], '2,0', 'safe', '0,0 0,1', '两个数字都是1，较大邻域多出的左侧两格都安全。')
            ]
        }),
        createPattern({
            id: 'diagonal',
            name: '对角推理',
            level: 3,
            description: '联合对角方向上的多个数字，交叉确定未揭格。',
            explanation: '对角相邻的数字会共享部分邻域。结合两侧数字逐步排除，可以确定斜线上的雷位。',
            example: { layout: ['#..', '.#.', '..#'], mines: '0,0 2,2' },
            trainingBoards: [
                createBoard(['#..', '.#.', '..#'], '0,0 2,2', 'mine', '0,0 2,2', '沿主对角线交叉比较数字，可确定两端是雷、中间安全。'),
                createBoard(['..#', '.#.', '#..'], '2,0 0,2', 'mine', '2,0 0,2', '沿副对角线交叉比较数字，可确定两端是雷、中间安全。'),
                createBoard(['#...', '.#..', '..#.', '...#'], '0,0 2,2', 'mine', '0,0 2,2', '四格对角线上，周围数字共同确定第1、3格是雷。'),
                createBoard(['...#', '..#.', '.#..', '#...'], '3,0 1,2', 'mine', '3,0 1,2', '副对角线上的交叉约束确定第1、3格是雷。'),
                createBoard(['.#.', '#..', '..#'], '1,0 2,2', 'mine', '1,0 2,2', '折线两侧的数字共同约束三个斜向格，可确定首尾是雷。')
            ]
        }),
        createPattern({
            id: 'probability',
            name: '概率判断',
            level: 3,
            description: '没有确定解时，比较所有合法布局并选择雷概率最低的格子。',
            explanation: '每个符合已揭示数字的雷位组合都视为一种可能；某格出现雷的组合占比越低，点击风险越小。',
            example: { layout: ['###', '#.#', '###'], mines: '0,0' },
            trainingBoards: [
                createBoard(['#.#', '###', '#..'], '0,1 1,1', 'lowest-risk', '0,0 2,0 0,1', '共有6种合法布局；所选三格各在2种布局中为雷，风险最低，约33.3%。'),
                createBoard(['#.#', '###', '#..'], '0,0 0,1 1,1', 'lowest-risk', '0,2', '共有6种合法布局；左下格只在2种布局中为雷，风险最低，约33.3%。'),
                createBoard(['.##', '###', '#..'], '0,1 1,1', 'lowest-risk', '2,1 0,2', '共有6种合法布局；所选两格各在2种布局中为雷，风险最低，约33.3%。'),
                createBoard(['###', '.#.', '.##'], '1,0 1,1', 'lowest-risk', '2,0 1,0 2,2', '旋转题面不改变约束关系；所选三格的雷概率最低，约33.3%。'),
                createBoard(['..#', '###', '#.#'], '2,2 2,1 1,1', 'lowest-risk', '2,0', '共有6种合法布局；右上格的雷概率最低，约33.3%。')
            ]
        })
    ];

    // ==================== 进度管理 ====================

    var progress = {};

    function loadProgress() {
        try {
            var saved = Storage.get(STORAGE_KEY);
            if (saved && typeof saved === 'object') {
                progress = saved;
            }
        } catch (e) {
            progress = {};
        }
        ensureProgressInit();
    }

    function saveProgress() {
        try {
            Storage.set(STORAGE_KEY, progress);
        } catch (e) {}
    }

    function ensureProgressInit() {
        // 默认解锁第一个模式
        if (!progress['corner-1']) {
            progress['corner-1'] = { unlocked: true, completed: 0, correct: 0, bestTime: null, rating: 'none' };
        }
        // 其他模式默认未解锁
        for (var i = 0; i < PATTERNS.length; i++) {
            var pid = PATTERNS[i].id;
            if (!progress[pid]) {
                progress[pid] = { unlocked: false, completed: 0, correct: 0, bestTime: null, rating: 'none' };
            }
        }
    }

    // ==================== 公共 API ====================

    function getPatterns() {
        return PATTERNS.slice();
    }

    function getPattern(id) {
        for (var i = 0; i < PATTERNS.length; i++) {
            if (PATTERNS[i].id === id) return PATTERNS[i];
        }
        return null;
    }

    function getProgress(id) {
        if (id) return progress[id] || null;
        return Object.assign({}, progress);
    }

    function isUnlocked(id) {
        var p = progress[id];
        return p && p.unlocked;
    }

    function getTrainingBoard(patternId, index) {
        var pattern = getPattern(patternId);
        if (!pattern || !pattern.trainingBoards || index < 0 || index >= pattern.trainingBoards.length) return null;
        return pattern.trainingBoards[index];
    }

    function checkAnswer(patternId, boardIndex, selectedCells) {
        var board = getTrainingBoard(patternId, boardIndex);
        if (!board) return { correct: false, reason: '题目不存在' };

        var expected = board.targets.slice().sort(function(a, b) { return a.x - b.x || a.y - b.y; });
        var actual = selectedCells.slice().sort(function(a, b) { return a.x - b.x || a.y - b.y; });
        var answerName = board.answerType === 'mine' ? '雷' : board.answerType === 'safe' ? '安全格' : '低风险格';

        if (expected.length !== actual.length) {
            return {
                correct: false,
                reason: '选择数量不对。应选择 ' + expected.length + ' 个' + answerName + '，你选择了 ' + actual.length + ' 个。',
                expected: expected,
                answerType: board.answerType
            };
        }

        for (var i = 0; i < expected.length; i++) {
            if (expected[i].x !== actual[i].x || expected[i].y !== actual[i].y) {
                return {
                    correct: false,
                    reason: '选择位置有误。正确答案已高亮显示。',
                    expected: expected,
                    answerType: board.answerType
                };
            }
        }

        return {
            correct: true,
            expected: expected,
            answerType: board.answerType,
            explanation: board.explanation
        };
    }

    function getRatingValue(rating) {
        if (rating === 'gold') return 3;
        if (rating === 'silver') return 2;
        if (rating === 'bronze') return 1;
        return 0;
    }

    function recordResult(patternId, isCorrect, timeMs) {
        var p = progress[patternId];
        if (!p) return;

        p.completed++;
        if (isCorrect) p.correct++;

        if (isCorrect && (p.bestTime === null || timeMs < p.bestTime)) {
            p.bestTime = timeMs;
        }

        // 评级计算（只升级不降级）
        var accuracy = p.completed > 0 ? (p.correct / p.completed) : 0;
        var newRating = p.rating;
        if (p.completed >= 5) {
            if (accuracy >= 0.9 && p.bestTime !== null && p.bestTime < 10000) {
                newRating = 'gold';
            } else if (accuracy >= 0.8) {
                newRating = 'silver';
            } else if (accuracy >= 0.6) {
                newRating = 'bronze';
            } else {
                newRating = 'none';
            }
        } else if (p.completed >= 3 && accuracy >= 0.6) {
            newRating = 'bronze';
        }
        // 只升级，保留已获得的高评级
        if (getRatingValue(newRating) > getRatingValue(p.rating)) {
            p.rating = newRating;
        }

        // 解锁下一个模式
        tryUnlockNext(patternId);

        saveProgress();
    }

    function tryUnlockNext(currentId) {
        var p = progress[currentId];
        if (!p) return;

        var accuracy = p.completed > 0 ? (p.correct / p.completed) : 0;
        if (p.completed >= 5 && accuracy >= 0.6) {
            for (var i = 0; i < PATTERNS.length - 1; i++) {
                if (PATTERNS[i].id === currentId) {
                    var nextId = PATTERNS[i + 1].id;
                    if (progress[nextId] && !progress[nextId].unlocked) {
                        progress[nextId].unlocked = true;
                        // 派发解锁事件
                        document.dispatchEvent(new CustomEvent('patternUnlocked', {
                            detail: { patternId: nextId }
                        }));
                    }
                    break;
                }
            }
        }
    }

    function resetProgress() {
        progress = {};
        ensureProgressInit();
        saveProgress();
    }

    // ==================== 初始化 ====================

    loadProgress();

    return {
        getPatterns: getPatterns,
        getPattern: getPattern,
        getProgress: getProgress,
        isUnlocked: isUnlocked,
        getTrainingBoard: getTrainingBoard,
        checkAnswer: checkAnswer,
        recordResult: recordResult,
        resetProgress: resetProgress
    };
})();
